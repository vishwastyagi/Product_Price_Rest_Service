package com.globalmart.product.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.globalmart.product.domain.Catalogue;
import com.globalmart.product.domain.Product;
import com.globalmart.product.service.ProductService;

@Controller
@RequestMapping("/product")
public class ProductController {

	private ProductService productService;

	@Autowired
	public void setProductService(ProductService productService) {
		this.productService = productService;
	}

	@RequestMapping(value="/all", method = RequestMethod.GET, headers = "Accept=application/json")
	public ResponseEntity<Object> productList() {
		try {
			List<Product> productList = productService.findAll();
			if (productList == null || productList.isEmpty()) {
				return new ResponseEntity<Object>("No Product Found",
						HttpStatus.NOT_FOUND);
			}
			List<Product> proxyProductList = new ArrayList<Product>();
			Product proxyProduct;
			Catalogue proxyCatalogue;

			for (Product product : productList) {
				proxyProduct = new Product();
				proxyProduct.setProductId(product.getProductId());
				proxyProduct.setProductName(product.getProductName());
				proxyProduct.setProductPrice(product.getProductPrice());
				proxyProduct.setVersion(product.getVersion());

				proxyCatalogue = new Catalogue();
				proxyCatalogue.setCatalogueId(product.getCatalogue()
						.getCatalogueId());
				proxyCatalogue.setCatalogueName(product.getCatalogue()
						.getCatalogueName());
				proxyCatalogue.setBusinessUnitName(product.getCatalogue()
						.getBusinessUnitName());
				proxyCatalogue.setVersion(product.getCatalogue().getVersion());

				proxyProduct.setCatalogue(proxyCatalogue);

				proxyProductList.add(proxyProduct);
			}
			return new ResponseEntity<Object>(proxyProductList, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Object>(
					"Server Error occured while handling request",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@RequestMapping(method = RequestMethod.POST, headers = "Accept=application/json")
	public ResponseEntity<Object> product(@RequestBody Product product) {
		try {
			long productId = productService.save(product);
			return new ResponseEntity<Object>("productId:"+productId, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Object>(
					"Server Error occured while handling request",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@RequestMapping(method = RequestMethod.DELETE, headers = "Accept=application/json")
	public ResponseEntity<Object> product(@RequestParam(required=true,value="productId") String productId) {
		try {
			productService.delete(productId);
			return new ResponseEntity<Object>("Product with ID: " + productId
					+ " deleted from database", HttpStatus.OK);
		} catch (NumberFormatException e) {
			return new ResponseEntity<Object>("Incorrect product Id format",
					HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Object>(
					"Server Error occured while handling request",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
