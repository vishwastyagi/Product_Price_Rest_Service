package com.globalmart.product.repository;

import java.util.List;

import com.globalmart.product.domain.Product;

public interface ProductRepository{
	List<Product> findAll();

	long save(Product product);

	void delete(long productId);
}
