package com.globalmart.product.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.globalmart.product.domain.Product;
import com.globalmart.product.repository.ProductRepository;
import com.globalmart.product.service.ProductService;
import com.google.common.collect.Lists;
@Service("productService")
@Transactional("productTransactionManager")
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	private ProductRepository productRepository;

	@Transactional(readOnly = true)
	public List<Product> findAll() {
		return Lists.newArrayList(productRepository.findAll());
	}

	public long save(Product product) {
		return productRepository.save(product);
	}
	
	public void delete(String productId){
		long prodId=Long.parseLong(productId);
		productRepository.delete(prodId);
	}
}
