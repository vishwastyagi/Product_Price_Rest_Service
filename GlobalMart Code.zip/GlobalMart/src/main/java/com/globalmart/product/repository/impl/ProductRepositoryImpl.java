package com.globalmart.product.repository.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.globalmart.product.domain.Product;
import com.globalmart.product.repository.ProductRepository;
@Repository("productRepository")
public class ProductRepositoryImpl implements ProductRepository{

	@PersistenceContext(name="productEMF",unitName="productEMF")
	@Qualifier(value = "productEMF")
	private EntityManager entityManager;

	public List<Product> findAll() {
		return entityManager.createQuery("from Product",Product.class).getResultList();
	}

	public long save(Product product) {
		entityManager.persist(product);
		entityManager.flush();
		entityManager.refresh(product);
		return product.getProductId();
	}
	
	public void delete(long productId){
		Product product=entityManager.find(Product.class, productId);
		entityManager.remove(product);
	}

}
