package com.globalmart.product.service;

import java.util.List;

import com.globalmart.product.domain.Product;

public interface ProductService {

	List<Product> findAll();

	long save(Product product);

	public void delete(String productId);

}
