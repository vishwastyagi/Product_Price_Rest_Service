package com.globalmart.price.domain;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Version;

@Entity
@Table(name = "catalogue")
public class Catalogue {
	private long catalogueId;
	private String catalogueName;
	private String businessUnitName;
	private Set<Product> productList;
	private int version;

	public Catalogue(int catalogueId, String businessUnitName,
			String catalogueName, Set<Product> productList, int version) {
		super();
		this.catalogueId = catalogueId;
		this.catalogueName = catalogueName;
		this.businessUnitName = businessUnitName;
		this.productList = productList;
		this.version = version;
	}

	public Catalogue() {
		super();
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "catalogue_id", unique = true, nullable = false)
	public long getCatalogueId() {
		return catalogueId;
	}

	public void setCatalogueId(long catalogueId) {
		this.catalogueId = catalogueId;
	}

	@Column(name = "business_unit_name", nullable = false)
	public String getBusinessUnitName() {
		return businessUnitName;
	}

	public void setBusinessUnitName(String businessUnitName) {
		this.businessUnitName = businessUnitName;
	}

	//@OneToMany(fetch = FetchType.LAZY, mappedBy = "catalogue", orphanRemoval=true, targetEntity = Product.class)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "catalogue", cascade = CascadeType.ALL)
	public Set<Product> getProductList() {
		return productList;
	}

	public void setProductList(Set<Product> productList) {
		this.productList = productList;
	}

	@Column(name = "catalogue_name")
	public String getCatalogueName() {
		return catalogueName;
	}

	public void setCatalogueName(String catalogueName) {
		this.catalogueName = catalogueName;
	}

	@Version
	@Column(name = "VERSION")
	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	@Override
	public String toString() {
		return "Catalogue [catalogueId=" + catalogueId + ", catalogueName="
				+ catalogueName + ", businessUnitName=" + businessUnitName
				+ ", version=" + version + "]";
	}

}
