package com.globalmart.price.repository.impl;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.globalmart.price.domain.Product;
import com.globalmart.price.repository.PriceRepository;

@Repository("priceRepository")
public class PriceRepositoryImpl implements PriceRepository {
	
	@PersistenceContext(name="priceEMF",unitName="priceEMF")
	@Qualifier(value = "priceEMF")
	private EntityManager entityManager;

	public Double getProduct(Long prodId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();

		CriteriaQuery<Double> criteriaQuery = criteriaBuilder
				.createQuery(Double.class);
		
		Root<Product> root = criteriaQuery.from(Product.class);

		criteriaQuery.select(root.get("productPrice").as(Double.class));
		
		criteriaQuery.where(criteriaBuilder.equal(root.get("productId"),
				prodId));

		TypedQuery<Double> typedQuery = entityManager
				.createQuery(criteriaQuery);

		Double productPrice = typedQuery.getSingleResult();
		return productPrice;
	}

}
