package com.globalmart.price.service;

public interface PriceService {

	Double getProductPrice(String productId);

}
