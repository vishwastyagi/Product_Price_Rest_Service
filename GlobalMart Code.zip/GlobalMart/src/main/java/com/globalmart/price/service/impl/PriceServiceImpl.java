package com.globalmart.price.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.globalmart.price.repository.PriceRepository;
import com.globalmart.price.service.PriceService;

@Service("priceService")
@Transactional("priceTransactionManager")
public class PriceServiceImpl implements PriceService{

	@Autowired
	private PriceRepository priceRepository;
	
	public Double getProductPrice(String productId) {
		Long prodId=Long.parseLong(productId);
		Double productPrice= priceRepository.getProduct(prodId);
		return productPrice;
	}

}
