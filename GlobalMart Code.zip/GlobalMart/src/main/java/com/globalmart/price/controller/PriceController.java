package com.globalmart.price.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.globalmart.price.service.PriceService;

@Controller
@RequestMapping("/price")
public class PriceController {

	private PriceService priceService;
	
	@Autowired
	public void setPriceService(PriceService priceService) {
		this.priceService = priceService;
	}

	@RequestMapping(method = RequestMethod.GET, headers = "Accept=application/json")
	public ResponseEntity<Object> price(
			@RequestParam(required = true, value = "productId") String productId) {
		try {
			Double productPrice = priceService.getProductPrice(productId);
			if(productPrice==null || productPrice==0.0){
				return new ResponseEntity<Object>("No Product Found With given Id "+productId,
						HttpStatus.NOT_FOUND);
			}
			return new ResponseEntity<Object>("Price of product with id: "
					+ productId + " is " + productPrice, HttpStatus.OK);
		} catch (NumberFormatException e) {
			return new ResponseEntity<Object>("Incorrect product Id format",
					HttpStatus.BAD_REQUEST);
		} catch (NullPointerException e) {
			return new ResponseEntity<Object>("No Product Found",
					HttpStatus.NOT_FOUND);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Object>(
					"Server Error occured while handling request",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
