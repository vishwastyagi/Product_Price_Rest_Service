package com.globalmart.price.repository;


public interface PriceRepository {

	Double getProduct(Long prodId);

}
