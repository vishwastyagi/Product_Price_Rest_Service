package com.globalmart.product.controller;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.globalmart.product.domain.Catalogue;
import com.globalmart.product.domain.Product;
import com.globalmart.product.service.ProductService;
import com.globalmart.util.TestUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/servlet-context.xml", "/root-context.xml" })
public class ProductControllerTest {

	private MockMvc mockMvc;

	@Mock
	private ProductService productServiceMock;

	@InjectMocks
	private ProductController productController;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(productController).build();
	}

	@Test
	public void testProductList() throws Exception {

		Catalogue catalogue = new Catalogue();
		catalogue.setCatalogueId(1);
		catalogue.setBusinessUnitName("B1");
		catalogue.setVersion(1);
		catalogue.setCatalogueName("C1");

		Product first = new Product();
		first.setProductId(1);
		first.setProductName("P1");
		first.setProductPrice(10.22);
		first.setVersion(1);
		first.setCatalogue(catalogue);

		Product secound = new Product();
		secound.setProductId(2);
		secound.setProductName("P2");
		secound.setProductPrice(11.22);
		secound.setVersion(1);
		secound.setCatalogue(catalogue);

		when(productServiceMock.findAll()).thenReturn(
				Arrays.asList(first, secound));

		mockMvc.perform(get("/product/all")).andExpect(status().isOk())
				.andExpect(content().contentType(TestUtil.APPLICATION_JSON))
				.andExpect(jsonPath("$", hasSize(2)))
				.andExpect(jsonPath("$[0].productId", is(1)))
				.andExpect(jsonPath("$[0].productName", is("P1")))
				.andExpect(jsonPath("$[0].productPrice", is(10.22)))
				.andExpect(jsonPath("$[0].version", is(1)))
				.andExpect(jsonPath("$[1].productId", is(2)))
				.andExpect(jsonPath("$[1].productPrice", is(11.22)))
				.andExpect(jsonPath("$[1].productName", is("P2")))
				.andExpect(jsonPath("$[1].version", is(1)));
	}

	@Test
	public void testSaveProduct() throws Exception {
		Catalogue catalogue = new Catalogue();
		catalogue.setCatalogueId(1);

		Product product = new Product();
		product.setProductName("P7");
		product.setProductPrice(10.22);
		product.setVersion(1);
		product.setCatalogue(catalogue);

		when(productServiceMock.save(product)).thenReturn(8L);

		mockMvc.perform(
				post("/product").contentType(TestUtil.APPLICATION_JSON)
						.content(TestUtil.convertObjectToJsonBytes(product)))
				.andExpect(status().isOk())
				.andExpect(content().contentType(TestUtil.APPLICATION_JSON))
				.equals("productId:" + 8);

	}

	@Test
	public void testDeleteProduct() throws Exception {
		String productId = "2";
		String response = "Product with ID: " + productId
				+ " deleted from database";

		doNothing().when(productServiceMock).delete(productId);

		mockMvc.perform(delete("/product?productId=" + productId))
				.andExpect(status().isOk())
				.andExpect(content().contentType(TestUtil.APPLICATION_JSON))
				.equals(response);

	}
}
