package com.globalmart.util;

import java.io.IOException;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.http.MediaType;

public class TestUtil {

	public static final MediaType APPLICATION_JSON = new MediaType(
			MediaType.APPLICATION_JSON.getType(),
			MediaType.APPLICATION_JSON.getSubtype());

	public static byte[] convertObjectToJsonBytes(Object object)
			throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		return mapper.writeValueAsBytes(object);
	}
}