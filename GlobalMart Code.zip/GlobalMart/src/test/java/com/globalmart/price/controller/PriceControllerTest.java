package com.globalmart.price.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.globalmart.price.service.PriceService;
import com.globalmart.util.TestUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/servlet-context.xml", "/root-context.xml" })
public class PriceControllerTest {

	private MockMvc mockMvc;

	@Mock
	private PriceService priceServiceMock;

	@InjectMocks
	private PriceController priceController;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(priceController).build();
	}

	@Test
	public void testPrice() throws Exception {
		String productId = "2";
		double productPrice=10.22;
		String response="Price of product with id: "+ productId + " is " + productPrice;
		
		when(priceServiceMock.getProductPrice(productId)).thenReturn(10.22);
		mockMvc.perform(get("/price?productId=" + productId))
		.andExpect(status().isOk())
		.andExpect(content().contentType(TestUtil.APPLICATION_JSON))
		.equals(response);
	}
}
